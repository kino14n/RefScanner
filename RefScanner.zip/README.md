# RefScanner

**RefScanner** es una herramienta ligera en Flask que extrae y reporta los códigos entre `Ref:` y `/` de todos los PDFs de la carpeta `static/pdfs`.
